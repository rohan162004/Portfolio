export const experiences = [
  {
    id: 1,
    title: "Software Developer Trainee",
    company: "Elsner Technologies Private Ltd.",
    duration: "(Feb 2025 - Present)",
  },
  {
    id: 2,
    title: "Freelancer Developer",
    company: "",
    duration: "(Jun 2021 - Jan 2022)",
  },
  {
    id: 3,
    title: "Software Developer Intern",
    company: "Apni Technologies",
    duration: "(Jan 2022 - Present)",
  },
];
