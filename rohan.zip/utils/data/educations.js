export const educations = [
  {
    id: 1,
    title: "Bachlor of Engineering in Computer Engineering",
    duration: "2021 - 2025",
    institution: "Gujarat Technological University",
  },
  {
    id: 2,
    title: "Higher Secondary Certificate",
    duration: "2019 - 2021",
    institution: "B.M.Commerce Higher Secondary School",
  },
  {
    id: 3,
    title: "Secondary School Certificate",
    duration: "2009 - 2019",
    institution: "B.M.Commerce Higher Secondary School",
  },
];
